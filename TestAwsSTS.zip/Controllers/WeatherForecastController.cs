﻿using Amazon.S3;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using TestAwsSTS.Service;

namespace TestAwsSTS.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {


        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IAWSSTSTest _stsService;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IAWSSTSTest stsService)
        {
            _stsService = stsService;
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bucketName"></param>
        /// <param name="expireTime"></param>
        /// <returns></returns>
        [HttpGet("sts")]
        public async Task<string> GetSTSAsync(string bucketName, string dirName, int expireTime)
        {
            var result = await _stsService.GetSTSAsync(OssObjectHandleEnum.READ_WRITE, bucketName, dirName, expireTime);
            return result;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="endpoint"></param>
        /// <param name="ak"></param>
        /// <param name="sk"></param>
        /// <param name="token"></param>
        /// <param name="bucketName"></param>
        /// <returns></returns>
        [HttpPost("sts/objects")]
        public string GetSTSObjectList(string endpoint, string ak, string sk, string token, string bucketName)
        {
            var config = new AmazonS3Config()
            {
                ServiceURL = endpoint
            };
            try
            {
                var client = new AmazonS3Client(ak, sk, token, config);
                var response = client.ListObjectsAsync(bucketName).GetAwaiter().GetResult();
                if (response.HttpStatusCode == HttpStatusCode.OK)
                {
                    return JsonSerializer.Serialize(response.ResponseMetadata);
                }
            }
            catch (AmazonS3Exception e)
            {
                throw e;
            }
            throw new Exception("request fail");
        }
    }
}
