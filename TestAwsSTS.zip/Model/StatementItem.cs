﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestAwsSTS
{
    /// <summary>
    /// 
    /// </summary>
    public class StatementItem
    {
        /// <summary>
        /// 
        /// </summary>
        public string Action { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Effect { get; set; } = "Allow";
        /// <summary>
        /// 
        /// </summary>
        public List<string> Resource { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Sid { get; set; }
    }
    /// <summary>
    /// token
    /// </summary>
    public class Root
    {
        /// <summary>
        /// 
        /// </summary>
        public List<StatementItem> Statement { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Version { get; set; } = "1";
    }
}
