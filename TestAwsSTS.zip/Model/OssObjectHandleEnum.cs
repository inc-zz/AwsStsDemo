﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestAwsSTS
{

    /// <summary>
    /// 
    /// </summary>
    public enum OssObjectHandleEnum
    {
        READ = 1,
        WRITE, 
        READ_WRITE
    }
}
