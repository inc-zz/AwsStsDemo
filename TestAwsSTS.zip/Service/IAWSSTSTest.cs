﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestAwsSTS.Service
{
    public interface IAWSSTSTest
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="bucketName"></param>
        /// <param name="dirName"></param>
        /// <param name="expireTime"></param>
        /// <returns></returns>
        Task<string> GetSTSAsync(OssObjectHandleEnum type, string bucketName, string dirName, int expireTime);
         
    }
}
