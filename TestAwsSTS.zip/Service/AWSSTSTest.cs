﻿using Amazon.SecurityToken;
using Amazon.SecurityToken.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace TestAwsSTS.Service
{
    /// <summary>
    /// 
    /// </summary>
    public class AWSSTSTest: IAWSSTSTest
    {

        /// <summary>
        /// Get StsToken
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public async Task<string> GetSTSAsync(OssObjectHandleEnum type, string bucketName, string dirName, int expireTime)
        {
            var accessKey = "";
            var secretKey = "";
            var stsEndpoint = "";
            var endpoint = "";

            AmazonSecurityTokenServiceClient stsClient = new AmazonSecurityTokenServiceClient(accessKey, secretKey,
                new AmazonSecurityTokenServiceConfig
                {
                    ServiceURL = stsEndpoint
                });

            var sid = Guid.NewGuid().ToString("N").ToUpper();
            var request = new GetFederationTokenRequest
            {
                Name = bucketName,
                DurationSeconds = expireTime
            };
            var listResource = string.IsNullOrWhiteSpace(dirName) ? $"[\"arn:aws:s3:::{bucketName}/*\"]" : $"[\"arn:aws:s3:::{bucketName}/{dirName}/*\"]";

            var listDese = JsonSerializer.Deserialize<List<string>>(listResource);
            List<StatementItem> items = new List<StatementItem>();

            //AWS OSS Policy :
            /*"\"s3:ListBucket\",
             * \"s3:ListObjects\",
             * \"s3:GetObject\",
             * \"s3:PutObject\",
             * \"s3:DeleteObject\",
             * \"s3:RestoreObject\",
             * \"s3:AbortMultipartUpload\",
             * \"s3:PutObjectAcl\",
             * \"s3:GetObjectAcl\",
             * \"s3:ListParts\",
             * \"s3:GetVodPlaylist\",
             * \"s3:PostVodPlaylist\",
             * \"s3:PublishRtmpStream\",
             * \"s3:ListObjectVersions\",
             * \"s3:GetObjectVersion\",
             * \"s3:GetObjectVersionAcl\",
             * \"s3:RestoreObjectVersion";*/

            switch (type)
            {
                case OssObjectHandleEnum.READ:
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:Get*", Effect = "Allow", Sid = Guid.NewGuid().ToString("N") });
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:List*", Effect = "Allow", Sid = Guid.NewGuid().ToString("N") });
                    break;
                case OssObjectHandleEnum.WRITE:
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:*", Effect = "Allow", Sid = sid });
                    break;
                case OssObjectHandleEnum.READ_WRITE:
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:Get*", Effect = "Allow", Sid = Guid.NewGuid().ToString("N") });
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:List*", Effect = "Allow", Sid = Guid.NewGuid().ToString("N") });
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:Put*", Effect = "Allow", Sid = sid });
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:Restore*", Effect = "Allow", Sid = sid });
                    items.Add(new StatementItem() { Resource = listDese, Action = "s3:Post*", Effect = "Allow", Sid = sid });
                    break;
            }
            Root root = new Root() { Statement = items, Version = "2012-10-17" };
            request.Policy = JsonSerializer.Serialize(root);

            GetFederationTokenResponse response = await stsClient.GetFederationTokenAsync(request);
            if (response.HttpStatusCode == HttpStatusCode.OK)
            {
                var data = new
                {
                    Token = response.Credentials.SessionToken,
                    AccessKey = response.Credentials.AccessKeyId,
                    SecurityKey = response.Credentials.SecretAccessKey,
                    Endpoint = endpoint
                };
                return JsonSerializer.Serialize(data);
            }
            return "reuest fail";

        }

    }
}
